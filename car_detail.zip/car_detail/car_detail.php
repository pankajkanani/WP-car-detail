<?php
/*
Plugin Name: Car Details
Description: A plugin to manage cars with custom post type and taxonomies, and to display car entries and lists using shortcodes. [car_entry] shortcode on any page or post where you want the form to appear. [car-list] shortcode to embed a dynamic car listing on your site.
Version: 1.0
Author: Pankaj
*/

// Register Car Custom Post Type
function register_car_post_type() {
    $labels = array(
        'name'               => 'Cars',
        'singular_name'      => 'Car',
        'menu_name'          => 'Cars',
        'name_admin_bar'     => 'Car',
        'add_new'            => 'Add New',
        'add_new_item'       => 'Add New Car',
        'new_item'           => 'New Car',
        'edit_item'          => 'Edit Car',
        'view_item'          => 'View Car',
        'all_items'          => 'All Cars',
    );
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'has_archive'        => true,
        'supports'           => array('title', 'thumbnail'),
        'show_in_rest'       => true,
    );
    register_post_type('car', $args);
}
add_action('init', 'register_car_post_type');

// Register Taxonomies
function register_car_taxonomies() {
    // Make Taxonomy
    register_taxonomy('make', 'car', array(
        'label'        => 'Make',
        'hierarchical' => true,
        'show_in_rest' => true,
    ));

    // Model Taxonomy
    register_taxonomy('model', 'car', array(
        'label'        => 'Model',
        'hierarchical' => true,
        'show_in_rest' => true,
    ));

    // Year Taxonomy
    register_taxonomy('year', 'car', array(
        'label'        => 'Year',
        'hierarchical' => true,
        'show_in_rest' => true,
    ));

    // Fuel Type Taxonomy
    register_taxonomy('fuel_type', 'car', array(
        'label'        => 'Fuel Type',
        'hierarchical' => true,
        'show_in_rest' => true,
    ));
}
add_action('init', 'register_car_taxonomies');

// Enqueue jQuery and custom script
function enqueue_car_entry_scripts_car() {
    wp_enqueue_script('jquery'); // Ensure jQuery is loaded
}
add_action('wp_enqueue_scripts', 'enqueue_car_entry_scripts_car');

// Shortcode for car entry form
function car_entry_form_shortcode() {
    ob_start();
    ?>
    <style>
    /* Inline CSS for the form */
    #car-entry-form {
        max-width: 600px;
        margin: 0 auto;
        padding: 20px;
        background-color: #f9f9f9;
        border: 1px solid #e0e0e0;
        border-radius: 10px;
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
    }
    #car-entry-form label {
        font-weight: bold;
        margin-top: 10px;
        display: block;
        color: #333;
    }
    #car-entry-form input[type="text"],
    #car-entry-form select,
    #car-entry-form input[type="file"] {
        width: 100%;
        padding: 10px;
        margin-top: 5px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 16px;
        box-sizing: border-box;
    }
    #car-entry-form input[type="radio"] {
        margin-right: 10px;
    }
    #car-entry-form input[type="radio"] + label {
        display: inline-block;
        font-size: 14px;
        color: #666;
        margin-right: 20px;
    }
    #car-entry-form button {
        background-color: #0073aa;
        color: white;
        border: none;
        padding: 10px 15px;
        border-radius: 5px;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }
    #car-entry-form button:hover {
        background-color: #005a8c;
    }
    #car-entry-form button:focus {
        outline: none;
    }
    #car-entry-form .form-section {
        margin-bottom: 20px;
    }
    #car-entry-form .form-header {
        font-size: 24px;
        margin-bottom: 20px;
        color: #333;
        text-align: center;
    }
    #car-entry-form #car-form-response {
        margin-top: 20px;
        font-size: 16px;
        color: #28a745; /* Success message color */
    }
    #car-entry-form #car-form-response.error {
        color: #dc3545; /* Error message color */
    }
    #car-form-response.success {
    color: #28a745; /* Green for success */
    }

    #car-form-response.error {
        color: #dc3545; /* Red for error */
    }

    </style>
    
    <form id="car-entry-form" enctype="multipart/form-data">
        <label for="car-name">Car Name</label>
        <input type="text" id="car-name" name="car_name" required><br>

        <label for="car-make">Make</label>
        <select id="car-make" name="make" required>
            <option value="">Select Make</option>
            <?php
            $makes = get_terms('make', array('hide_empty' => false));
            foreach ($makes as $make) {
                echo '<option value="'.$make->term_id.'">'.$make->name.'</option>';
            }
            ?>
        </select><br>

        <label for="car-model">Model</label>
        <select id="car-model" name="model" required>
            <option value="">Select Model</option>
            <?php
            $models = get_terms('model', array('hide_empty' => false));
            foreach ($models as $model) {
                echo '<option value="'.$model->term_id.'">'.$model->name.'</option>';
            }
            ?>
        </select><br>

        <label for="car-year">Year</label>
        <select id="car-year" name="year" required>
            <option value="">Select Year</option>
            <?php
            $years = get_terms('year', array('hide_empty' => false));
            foreach ($years as $year) {
                echo '<option value="'.$year->term_id.'">'.$year->name.'</option>';
            }
            ?>
        </select><br>

        <label for="fuel-type">Fuel Type</label><br>
        <?php
        $fuel_types = get_terms('fuel_type', array('hide_empty' => false));
        foreach ($fuel_types as $fuel_type) {
            echo '<input type="radio" name="fuel_type" value="'.$fuel_type->term_id.'" required> '.$fuel_type->name.'<br>';
        }
        ?><br>

        <label for="car-image">Upload Image</label>
        <input type="file" id="car-image" name="car_image" accept="image/*" required><br>

        <button type="submit">Submit</button>
    </form>
    <div id="car-form-response"></div>

    <script>
    jQuery(document).ready(function($) {
        $('#car-entry-form').submit(function(e) {
            e.preventDefault();
            var formData = new FormData(this);
            formData.append('action', 'car_entry_form'); // Required for WP AJAX

            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function(response) {
                    $('#car-form-response').html('<p>' + response + '</p>').removeClass('error').addClass('success');

                    // Clear the form fields
                    $('#car-entry-form')[0].reset();

                    // Hide the success/error message after 5 seconds
                    setTimeout(function() {
                        $('#car-form-response').fadeOut();
                    }, 5000);
                },
                error: function(xhr, status, error) {
                    $('#car-form-response').html('<p>There was an error: ' + error + '</p>').removeClass('success').addClass('error');

                    // Hide the error message after 5 seconds
                    setTimeout(function() {
                        $('#car-form-response').fadeOut();
                    }, 5000);

                }
            });
        });
    });
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('car_entry', 'car_entry_form_shortcode');

// Handle AJAX car entry form submission
function handle_car_entry_form_submission() {
    // Verify that the required fields are submitted
    if (
        isset($_POST['car_name']) && 
        isset($_POST['make']) && 
        isset($_POST['model']) && 
        isset($_POST['fuel_type']) &&
        isset($_POST['year'])
    ) {
        // Sanitize form inputs
        $car_name = sanitize_text_field($_POST['car_name']);
        $make = intval($_POST['make']);
        $model = intval($_POST['model']);
        $fuel_type = intval($_POST['fuel_type']);
        $year = intval($_POST['year']);  // Get the year value
        
        // Insert Car post
        $car_post_id = wp_insert_post(array(
            'post_title'  => $car_name,
            'post_type'   => 'car',
            'post_status' => 'publish',
        ));

        if ($car_post_id) {
            // Set taxonomies
            wp_set_post_terms($car_post_id, array($make), 'make');
            wp_set_post_terms($car_post_id, array($model), 'model');
            wp_set_post_terms($car_post_id, array($fuel_type), 'fuel_type');
            wp_set_post_terms($car_post_id, array($year), 'year');

            // Handle image upload
            if (!empty($_FILES['car_image']['name'])) {
                $uploaded_file = $_FILES['car_image'];
                $upload = wp_handle_upload($uploaded_file, array('test_form' => false));

                if (isset($upload['file'])) {
                    $attachment = array(
                        'post_mime_type' => $upload['type'],
                        'post_title'     => sanitize_file_name($uploaded_file['name']),
                        'post_content'   => '',
                        'post_status'    => 'inherit'
                    );

                    $attach_id = wp_insert_attachment($attachment, $upload['file'], $car_post_id);
                    require_once(ABSPATH . 'wp-admin/includes/image.php');
                    $attach_data = wp_generate_attachment_metadata($attach_id, $upload['file']);
                    wp_update_attachment_metadata($attach_id, $attach_data);
                    set_post_thumbnail($car_post_id, $attach_id);
                }
            }

            echo 'Car entry submitted successfully.';
        } else {
            echo 'There was an error submitting the car entry.';
        }
    } else {
        echo 'Required fields are missing.';
    }

    wp_die(); // This is required to terminate immediately and return a proper response.
}
add_action('wp_ajax_car_entry_form', 'handle_car_entry_form_submission');
add_action('wp_ajax_nopriv_car_entry_form', 'handle_car_entry_form_submission');

// Shortcode to display car listing
function car_list_shortcode() {
	?>

<style>
    /* CSS for the car list */
    .car-list {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    justify-content: center;
    padding: 20px;
}

/* Styles for car items */
.car-item {
    border: 1px solid #e0e0e0;
    border-radius: 10px;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
    background-color: #ffffff;
    width: 100%; /* Default to full width for mobile */
    max-width: 300px;
    padding: 15px;
    text-align: center;
    overflow: hidden;
    transition: transform 0.3s ease;
}

/* Hover effect for car items */
.car-item:hover {
    transform: scale(1.05);
}

/* Style for car images */
.car-item img {
    max-width: 100%;
    height: auto;
    border-radius: 10px;
}

/* Style for car titles */
.car-item h3 {
    font-size: 20px;
    margin: 10px 0;
    color: #333;
}

/* Style for car details */
.car-item p {
    font-size: 14px;
    color: #666;
    margin: 5px 0;
}

/* Responsive layout for larger screens */
@media (min-width: 768px) {
    .car-list {
        flex-direction: row;
        justify-content: space-between;
    }
    .car-item {
        width: calc(28.333% - 20px); /* Three items per row with gap consideration */
    }
}

/* Responsive layout for mobile screens */
@media (max-width: 767px) {
    .car-item {
        width: 100%;
        margin-bottom: 20px; /* Add margin for spacing between items */
    }
}
</style>
    

	
	<?php
    $args = array(
        'post_type' => 'car',
        'posts_per_page' => -1,
    );
    $query = new WP_Query($args);

    ob_start();

    if ($query->have_posts()) {
        ?><div class="car-list"><?php
        while ($query->have_posts()) : $query->the_post();
                $car_id = get_the_ID();
                $car_name = get_the_title();
                $make = wp_get_post_terms($car_id, 'make');
                $model = wp_get_post_terms($car_id, 'model');
                $year = wp_get_post_terms($car_id, 'year');
                $fuel_type = wp_get_post_terms($car_id, 'fuel_type');
                $image = get_the_post_thumbnail_url($car_id, 'full');
                ?>
                <div class="car-item">
                    <?php if ($image) : ?>
                        <img src="<?php echo esc_url($image); ?>" alt="<?php echo esc_attr($car_name); ?>">
                    <?php endif; ?>
                    <h3><?php echo esc_html($car_name); ?></h3>
                    <div class="car-details">
                        <p><strong>Make:</strong> <?php echo !empty($make) ? esc_html($make[0]->name) : 'N/A'; ?></p>
                        <p><strong>Model:</strong> <?php echo !empty($model) ? esc_html($model[0]->name) : 'N/A'; ?></p>
                        <p><strong>Year:</strong> <?php echo !empty($year) ? esc_html($year[0]->name) : 'N/A'; ?></p>
                        <p><strong>Fuel Type:</strong> <?php echo !empty($fuel_type) ? esc_html($fuel_type[0]->name) : 'N/A'; ?></p>
                    </div>
                </div>
                <?php
            endwhile;
            ?></div><?php
     } else {
        echo 'No cars found.';
    }

    wp_reset_postdata();
    return ob_get_clean();
}
add_shortcode('car-list', 'car_list_shortcode');